import React from "react";
import "./App.css";
import { connect } from "react-redux";
import NewComponent from "./NewComponent";
import { ADD } from "./store/actionTypes";
function App(props) {
  return (
    <div className="App">
      My Number: {props.value}
      {props.name}
      <br />
      <br />
      <button onClick={props.onAdd}>Increment</button>
      <br />
      <br />
      <button onClick={props.onSubtract}>Decrement</button>
      <br />
      <button onClick={props.onMultiply}>onMultiply</button>
      My New Compoonent
      <NewComponent />
    </div>
  );
}
const mapStateToProps = (state) => {
  return {
    value: state.value,
    name: state.myName,
  };
};

const mapDispatchToProps = (dispatch) => {
  return {
    onAdd: () => dispatch({ type: ADD, value: 1 }),
    onSubtract: () => dispatch({ type: "SUBTRACT", value: 1 }),
    onMultiply: () => dispatch({ type: "MULTIPLY", value: 10 }),
  };
};
export default connect(mapStateToProps, mapDispatchToProps)(App);

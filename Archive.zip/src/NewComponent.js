import React from "react";
import { connect } from "react-redux";
function NewComponent(props) {
  return <div>{props.school}</div>;
}

const mapStateToProps = (state) => {
  return {
    name: state.myName,
    school: state.school,
  };
};

export default connect(mapStateToProps, null)(NewComponent);
